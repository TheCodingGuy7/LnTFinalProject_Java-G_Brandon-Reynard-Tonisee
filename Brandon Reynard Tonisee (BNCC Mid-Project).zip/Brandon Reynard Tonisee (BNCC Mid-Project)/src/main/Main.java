package main;
import java.util.Scanner;
import java.util.Vector;
public class Main {
	Scanner scan = new Scanner(System.in);
	Vector<Listkaryawan>listkaryawan=new Vector<Listkaryawan>();
	public Main() {
	int choose=0;
	do {
		try {
		System.out.println("1. Insert data karyawan");
		System.out.println("2. View data karyawan");
		System.out.println("3. Update data karyawan");
		System.out.println("4. Delete data karyawan");
		System.out.println("5. Exit");
		System.out.print("Choose: ");
		choose=scan.nextInt();
		}
		catch(Exception E) {
			System.out.println("Invalid value!");
		}
		finally {
			scan.nextLine();
		}
		switch(choose) {
		case 1:
			inputdata();
			break;
		case 2:
			sortdata(listkaryawan);
			break;
		case 3:
			updatedata(listkaryawan);
			break;
		case 4:
			deletedata(listkaryawan);
			break;
		case 5:
			break;
		}
	}
	while(choose<1||choose>5||choose!=5);
	}
	public void inputdata(){
		String nama;
		String jeniskelamin;
		String jabatan;
		do {
		System.out.printf("Input nama karyawan [>=3]: ");
		nama=scan.nextLine();
		}
		while(nama.length()<3);
		do {
		System.out.printf("Input jenis kelamin [Laki-laki | Perempuan] (Case Sensitive): ");
		jeniskelamin=scan.nextLine();
		}
		while(!(jeniskelamin.equals("Laki-laki")||jeniskelamin.equals("Perempuan")));
		do {
		System.out.printf("Input jabatan [Manager | Supervisor | Admin] (Case Sensitive): ");
		jabatan=scan.nextLine();
		}
		while(!(jabatan.equals("Manager")||jabatan.equals("Supervisor")||jabatan.equals("Admin")));
		char randomhuruf1= (char)('A' + Math.random() * ('Z' - 'A' + 1));
		char randomhuruf2= (char)('A' + Math.random() * ('Z' - 'A' + 1));
		int randomangka1=(int)(Math.floor(Math.random()*9));
		int randomangka2=(int)(Math.floor(Math.random()*9));
		int randomangka3=(int)(Math.floor(Math.random()*9));
		int randomangka4=(int)(Math.floor(Math.random()*9));
		String randomcode1=Character.toString(randomhuruf1);
		String randomcode2=Character.toString(randomhuruf2);
		String randomcode3=Integer.toString(randomangka1);
		String randomcode4=Integer.toString(randomangka2);
		String randomcode5=Integer.toString(randomangka3);
		String randomcode6=Integer.toString(randomangka4);
		String randomcode=(randomcode1+randomcode2+"-"+randomcode3+randomcode4+randomcode5+randomcode6);
		System.out.println("Berhasil menambahkan "+jabatan+" dengan id "+randomcode);
		bonusKaryawan(listkaryawan,jabatan);
		listkaryawan.add(new Listkaryawan(nama,randomcode,jeniskelamin,jabatan));
		System.out.println("ENTER to return");
        scan.nextLine();
	}
	public static void bonusKaryawan(Vector<Listkaryawan> listkaryawan, String jabatan) {
		int jumlahKaryawan =0;
		for(Listkaryawan k:listkaryawan) {
			if(jabatan.equals(k.getJabatan())) {
				jumlahKaryawan++;
			}
		}
		if(jumlahKaryawan%3==0){
			int Count=0;
			Vector<String> idofkaryawan = new Vector<>();
			for(Listkaryawan k:listkaryawan) {
				if(k.getJabatan().equals(jabatan)) {
					int bonusGaji =k.getGaji();
					if(jabatan.equals("Manager")) {
						k.setGaji((int)(bonusGaji*0.1)+bonusGaji);
					}
					else if(jabatan.equals("Supervisor")) {
						k.setGaji((int)(bonusGaji*0.75)+bonusGaji);
					}
					else if(jabatan.equals("Admin")) {
						k.setGaji((int)(bonusGaji*0.05)+bonusGaji);
					}
					Count++;
					idofkaryawan.add(k.getId());
					if(Count==jumlahKaryawan) {
						if(jabatan.equals("Manager")) {
							System.out.print("Bonus sebesar 10% berhasil ditambahkan kepada karyawan dengan id\n");
							for(String a:idofkaryawan) {
								System.out.print(a+" ");
							}
						}
						else if(jabatan.equals("Admin")) {
							System.out.print("Bonus sebesar 5% berhasil ditambahkan kepada karyawan dengan id\n");
							int b=0;
							for(String a:idofkaryawan) {
								System.out.print(a);
								b++;
								if(b<idofkaryawan.size()){
									System.out.print(", ");
								}
							}
						}
						else {
							System.out.print("Bonus sebesar 7.5% berhasil ditambahkan kepada karyawan dengan id\n");
							for(String a:idofkaryawan) {
								System.out.print(a+" ");
							}
						}
						break;
					}
				}
			}
		}
		
	}
	public static void viewdata(Vector<Listkaryawan> listkaryawan) {

		if(listkaryawan.size()>0) {
			System.out.println("\n\n");
			for (int i = 0; i < listkaryawan.size() - 1; i++) {
	            for (int j = 0; j < listkaryawan.size() - i - 1; j++) {
	                if (listkaryawan.get(j).getNama().compareTo(listkaryawan.get(j+1).getNama()) > 0) {
	                    Listkaryawan temp= listkaryawan.get(j);
	                    listkaryawan.set(j, listkaryawan.get(j+1));
	                    listkaryawan.set(j+1, temp);
	                 }
	            }
	        }
			for(int i=0;i<114;i++) {
				System.out.print("=");
			}
			System.out.printf("\n| %-5s | %-15s | %-35s | %-15s | %-10s | %-15s |%n", "No","Kode Karyawan","Nama Karyawan","Jenis Kelamin","Jabatan","Gaji Karyawan");
			for(int i=0;i<114;i++) {
				System.out.print("=");
			}
			for(int i=0;i<listkaryawan.size();i++) {
				System.out.printf("\n| %5s | %15s | %35s | %15s | %10s | %15s |%n", 
						Integer.toString(i+1),listkaryawan.get(i).getId(),listkaryawan.get(i).getNama(),listkaryawan.get(i).getJeniskelamin(),
						listkaryawan.get(i).getJabatan(), Integer.toString(listkaryawan.get(i).getGaji()));
			}
			for(int i=0;i<114;i++) {
				System.out.print("=");
			}
			System.out.println("\n");
		}
		else {
			System.out.println("\n\n========================");
			System.out.println("\tNo Data");
			System.out.println("========================\n\n");
		}

	}
	public void sortdata(Vector<Listkaryawan>listkaryawan) {
		viewdata(listkaryawan);
		for (int i=0; i < listkaryawan.size(); i++) {
			for (int j = 0; j < listkaryawan.size() - 1 - i; j++) {
				if (listkaryawan.get(j).getNama().compareTo(listkaryawan.get(j+1).getNama()) > 0 ) {
					Listkaryawan temp = listkaryawan.get(j);
					listkaryawan.set(j, listkaryawan.get(j+1));
					listkaryawan.set(j+1, temp);
				}
			}
		}
		
	}
	public static void updatedata(Vector<Listkaryawan> listkaryawan) {
		viewdata(listkaryawan);
		if(listkaryawan.size()>0) {
			Scanner scan = new Scanner(System.in);
			System.out.print("\nMasukan nomor urutan karyawan yang ingin diupdate(must numeric!): " );
			int nourutan= Integer.parseInt(scan.nextLine());
			if(nourutan>0&&nourutan<=listkaryawan.size()) {
				String randomcodeid;
				while(true) {
					System.out.print("Input Kode karyawan : ");
					randomcodeid = scan.nextLine();
					if(randomcodeid.equals("0")) {
						randomcodeid=listkaryawan.get(nourutan-1).getId();
						break;
					}
					else if(!randomcodeid.equals("0")) {
						if(ValidasiId(listkaryawan, randomcodeid)) {
							break;
						}
					}
				}
				while(true) {
					System.out.print("Input nama karyawan [>=3]: ");
					String nama = scan.nextLine();
					if(!nama.equals("0")) {
						if(nama.length()>=3) {
							listkaryawan.get(nourutan-1).setNama(nama);
							break;
						}
					}
					else if(nama.equals("0")) {
						break;
					}
				}
				while(true) {
					System.out.print("Input jenis kelamin [Laki-laki | Perempuan] (Case Sensitive): ");
					String jeniskelamin = scan.nextLine();
					if(jeniskelamin.equals("0")) {
						break;
					}
					else if(!jeniskelamin.equals("0")) {
						if(jeniskelamin.equals("Laki-laki")||jeniskelamin.equals("Perempuan")) {
							listkaryawan.get(nourutan-1).setJeniskelamin(jeniskelamin);
							break;
						}
					}
				}
					while(true) {
					System.out.print("Input jabatan [Manager| Supervisor | Admin] (Case Sensitive): ");
					String jabatan = scan.nextLine();
					if(jabatan.equals("0")) {
						break;
					}
					if(!jabatan.equals("0")) {
						if(jabatan.equals("Manager")||jabatan.equals("Supervisor")||jabatan.equals("Admin")) {
							listkaryawan.get(nourutan-1).setJabatan(jabatan);
							break;
						}
					}
				}
					while(true) {
					System.out.print("Input Gaji Karyawan: ");
					int gaji = scan.nextInt();
					if(gaji==0) {
						System.out.println("Berhasil mengupdate karyawan dengan id "+listkaryawan.get(nourutan-1).getId());
						listkaryawan.get(nourutan-1).setId(randomcodeid);
						System.out.println("ENTER to return");
						scan.nextLine();
						break;
					}
					else if(gaji!=0&&gaji>0) {
						listkaryawan.get(nourutan-1).setGaji(gaji);
						System.out.println("Berhasil mengupdate karyawan dengan id "+listkaryawan.get(nourutan-1).getId());
						listkaryawan.get(nourutan-1).setId(randomcodeid);
						System.out.println("ENTER to return");
						scan.nextLine();
						break;
						}
					}
				}
			}
		}
	public static boolean ValidasiId(Vector<Listkaryawan> listkaryawan,String randomcodeid) {
	randomcodeid=randomcodeid.toUpperCase();
	if(randomcodeid.length()<=7) {
		if(Character.isAlphabetic(randomcodeid.charAt(0))) {
			if(Character.isAlphabetic(randomcodeid.charAt(1))) {
				if(randomcodeid.charAt(2)=='-') {
					for(int i=3;i<6;i++) {
						if(!Character.isDigit(randomcodeid.charAt(i))) {
							System.out.println("Format id salah!");
							return false;
						}
					}
				}
				else {
					System.out.println("Format id salah!");
					return false;
				}
			}
		}
	}
	else {
		System.out.println("Kode karyawan terlalu panjang!");
		return false;
	}
	return true;

}
	public static void deletedata(Vector<Listkaryawan>listkaryawan) {
		viewdata(listkaryawan);
		do{
			Scanner scan = new Scanner(System.in);
			System.out.print("Input nomor urutan karyawan yang ingin dihapus : ");
			int answer = Integer.parseInt(scan.nextLine());
			if(answer>0&&answer<=listkaryawan.size()) {
				System.out.println("Karyawan dengan kode "+listkaryawan.get(answer-1).getId()+" berhasil dihapus.");
				listkaryawan.remove(answer-1);
				System.out.println("ENTER to return");
				scan.nextLine();
			}
		}
		while(!(listkaryawan.size()>0));
	}
	public static void main (String[] args) {
		new Main();
	}
}
