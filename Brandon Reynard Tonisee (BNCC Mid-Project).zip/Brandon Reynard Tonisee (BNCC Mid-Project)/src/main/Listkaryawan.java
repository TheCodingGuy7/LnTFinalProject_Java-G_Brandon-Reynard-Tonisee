package main;

public class Listkaryawan {
	private String nama;
	private String id;
	private String jeniskelamin;
	private String jabatan;
	private int gaji;
//	public Karyawan(String nama, String jabatan,String id, String gender) {
//		this.nama=nama;
//		this.jabatan=jabatan;
//		
//
//	}
	public Listkaryawan(String nama,String randomcode,String jeniskelamin,String jabatan) {
		super();
		this.nama=nama;
		this.id=randomcode;
		this.jeniskelamin=jeniskelamin;
		this.jabatan=jabatan;
		if(jabatan.equals("Manager")) {
			this.gaji=8000000;
		}
		else if(jabatan.equals("Supervisor")) {
			this.gaji=6000000;
		}
		else if(jabatan.equals("Admin")) {
			this.gaji=4000000;
		}
	}
	public String getNama() {
		return nama;
	}
	public void setNama(String nama) {
		this.nama = nama;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getJeniskelamin() {
		return jeniskelamin;
	}
	public void setJeniskelamin(String jeniskelamin) {
		this.jeniskelamin = jeniskelamin;
	}
	public String getJabatan() {
		return jabatan;
	}
	public void setJabatan(String jabatan) {
		this.jabatan = jabatan;
	}
	public int getGaji() {
		return gaji;
	}
	public void setGaji(int gaji) {
		this.gaji = gaji;
	}
}

